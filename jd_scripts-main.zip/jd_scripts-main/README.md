# jd_scripts
> * 删除脚本内inviteCodes
> * 使用新助力库
> * 其他未修改，用法与原版相同

# BOT
### 助力码在@JD_ShareCode_Bot提交 [点击直达BOT](https://t.me/JD_ShareCode_Bot)

# Warning
### 带助力功能的脚本要使用本仓库的，其他仓库的没有适配新助力池
### IOS三件套在仓库内有订阅配置文件
### Node和Docker拉取使用本仓库地址
